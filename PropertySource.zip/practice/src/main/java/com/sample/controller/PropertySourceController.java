package com.sample.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PropertySourceController{
	@Autowired
	Environment evn;
	
	@Value("${insta}")
	String instagram;
	
	@Value("${fb}")
	String faceBook;
	
	@Value("${youtube}")
	String youTube;
	
	@Value("${ajay}")
	String ajayRole;
	
	@Value("${arun}")
	String arunRole;
	
	@GetMapping(value="execute")
	public ResponseEntity<?> execute()throws Exception{
		System.out.println("executing execute method");
		System.out.println(instagram);
		System.out.println(faceBook);
		System.out.println(youTube);
		System.out.println(arunRole);
		List<String> list = new ArrayList<>();
		list.add(instagram);
		list.add(faceBook);
		list.add(youTube);
		list.add(arunRole);
		
		Map<String,String> map = new HashMap<>();
		map.put("instagram", instagram);
		map.put("Facebook", faceBook);
		map.put("YouTube", youTube);
		map.put("ArunRole", arunRole);
		
		
		
		return new ResponseEntity<>(map, HttpStatus.OK);
		
	}
	
	@RequestMapping("home")
	public void home()
	{
		System.out.println("Executing home method");
	
	}
	
	

}
